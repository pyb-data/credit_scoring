from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home_func():


    import pandas as pd
    from sklearn.pipeline import Pipeline
    from data_preparation import prepareData
    from pickle import load, dump

    # Préparation des données
    dfApplication = prepareData('test')

    # Load du modèle
    pipeline = load(open('pipeline.pkl','rb'))

    # Prédiction du score (Les colonnes du dataframe doivent être dans l'ordre attendu par le modèle)
    imp = load(open('feature_importance.pkl','rb'))   
    dfApplication['SCORE'] = pipeline.predict_proba(dfApplication[list(imp.feature)]).T[1]

    # On ordonne les colonnes selon leur importance
    cols = ['SK_ID_CURR','SCORE']
    cols.extend(list(imp.feature))
    dfApplication = dfApplication[cols]

    # Sauvegarde
    dump(list(dfApplication.columns), open('dfApplicationDash_col.pkl','wb'))
    dump(list(dfApplication.values), open('dfApplicationDash_value.pkl','wb'))

    return 'Done!'
    #return render_template("home.html")

