# Lancer une instance EC2 Linux Ubuntu puis suivre pas à pas

sudo apt-get update
sudo apt-get install python3-pip
sudo apt-get install unzip
sudo apt-get install nginx
sudo apt-get install gunicorn3

sudo pip3 install flask

unzip projet_7.zip

cd projet_7
sudo mv projet_7 /etc/nginx/sites-enabled/projet_7

pip3 install Cython

# Avant d'installer streamlit, il faut installer Anaconda
pip3 install streamlit

pip3 install -r requirements.txt

#sudo service nginx restart
cd
cd projet_7
gunicorn3 app:app
streamlit run dashboard.py













