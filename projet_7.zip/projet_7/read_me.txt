
# PREPARATION DE L'ENVIRONNEMENT LINUX

# Lancer une instance EC2 Linux Ubuntu
# Dans les groupes de sécurité, ouvrir les ports 8080 et 8501
# Attacher une adresse IP elastic
# Récupérer l'IP publique IPv4 elastic et la mettre dans le fichier projet_7 (contenu dans projet_7.zip) après server_name, dans le fichier templates/index.html (dans projet_7.zip) ainsi que dans les deux scp (voir transfert de fichiers)
# Exécuter pas à pas les commandes suivantes


# connection shh à l'instance
ssh -i "projet_7.pem" ubuntu@ec2-13-37-98-86.eu-west-3.compute.amazonaws.com

sudo apt-get update



# TRANSFERT DES FICHIERS

sudo apt-get install unzip

# depuis le poste local, copier le fichier projet_7.zip sur l'instance
scp -i ~/.ssh/projet_7.pem projet_7.zip ubuntu@ec2-13-37-98-86.eu-west-3.compute.amazonaws.com:~/projet_7.zip
unzip projet_7.zip

# depuis le poste local, copier le fichier de données complet (à télécharger sur kaggle) en ajoutant "-FULL' à la fin du nom du fichier
scp -i ~/.ssh/projet_7.pem home-credit-default-risk-FULL.zip ubuntu@ec2-13-37-98-86.eu-west-3.compute.amazonaws.com:~/projet_7/home-credit-default-risk-FULL.zip
# dans EC2
mv home-credit-default-risk-FULL.zip "Projet+Mise+en+prod+-+home-credit-default-risk-FULL.zip"
mkdir "Projet+Mise+en+prod+-+home-credit-default-risk-FULL"
unzip "Projet+Mise+en+prod+-+home-credit-default-risk-FULL.zip" -d ~/projet_7
rm "Projet+Mise+en+prod+-+home-credit-default-risk-FULL.zip"

# dans EC2
rm projet_7.unzip



# CONFIGURATION SERVEUR

sudo apt-get install nginx

sudo nano /etc/nginx/nginx.conf
# ajouter les lignes suivantes dans http
        proxy_read_timeout 1000;
        proxy_connect_timeout 1000;
        proxy_send_timeout 1000;


sudo apt-get install gunicorn3
sudo mv projet_7 /etc/nginx/sites-enabled/projet_7




# INSTALLATIONS PYTHON

sudo apt-get install python3-pip


pip3 install flask
pip3 install Cython
pip3 install lightgbm
pip3 install seaborn
pip3 install pandas
pip3 install matplotlib
pip3 install numpy
pip3 install scipy
pip3 install statsmodels
pip3 install imblearn
pip3 install sklearn
pip3 install plotly
pip3 install altair


wget https://repo.anaconda.com/archive/Anaconda3-2021.05-Linux-x86_64.sh
sh Anaconda3-2021.05-Linux-x86_64.sh
rm Anaconda3-2021.05-Linux-x86_64.sh

# se déconnecter puis se reconnecter
pip3 install streamlit




# LANCEMENT

sudo service nginx restart

cd ~/projet_7

# Ouvrir la page html pour lancer le modèle
screen -S model
gunicorn3 --timeout 1000 app:app

# Ouvrir le dashboard
screen -S dashboard
streamlit run dashboard.py













